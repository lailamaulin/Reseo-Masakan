import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import '../models/recipe.dart';


class RecipeProvider with ChangeNotifier {
  List<Recipe> _recipes = [];
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  List<Recipe> get recipes => _recipes;

  Future<void> fetchRecipes() async {
    _recipes = await _dbHelper.getRecipes();
    notifyListeners();
  }

  Future<void> addRecipe(Recipe recipe) async {
    await _dbHelper.insertRecipe(recipe);
    await fetchRecipes();
  }

  Future<void> deleteRecipe(int id) async {
    await _dbHelper.deleteRecipe(id);
    await fetchRecipes();
  }

  Future<void> updateRecipe(Recipe recipe) async {
    await _dbHelper.updateRecipe(recipe);
    await fetchRecipes();
  }
}
