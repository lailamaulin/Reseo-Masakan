import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/recipe.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();
  static Database? _database;

  DatabaseHelper._privateConstructor();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    try {
      final dbPath = await getDatabasesPath(); // Mendapatkan path database
      final path = join(dbPath, 'recipes.db'); // Nama database yang ingin digunakan

      return await openDatabase(
        path,
        version: 1, // Versi database
        onCreate: _onCreate, // Fungsi untuk membuat tabel saat pertama kali dibuat
      );
    } catch (e) {
      throw Exception("Database Initialization Error: $e");
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    try {
      await db.execute('''
        CREATE TABLE recipes(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          preparation_time TEXT NOT NULL,
          ingredients TEXT NOT NULL,
          instructions TEXT NOT NULL
        )
      ''');
    } catch (e) {
      throw Exception("Table Creation Error: $e");
    }
  }

  Future<List<Recipe>> getRecipes() async {
    try {
      final db = await database;
      final List<Map<String, dynamic>> maps = await db.query('recipes');
      return maps.map((map) => Recipe.fromMap(map)).toList();
    } catch (e) {
      throw Exception("Get Recipes Error: $e");
    }
  }

  Future<void> insertRecipe(Recipe recipe) async {
    try {
      final db = await database;
      await db.insert('recipes', recipe.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
    } catch (e) {
      throw Exception("Insert Recipe Error: $e");
    }
  }

  Future<void> deleteRecipe(int id) async {
    try {
      final db = await database;
      await db.delete('recipes', where: 'id = ?', whereArgs: [id]);
    } catch (e) {
      throw Exception("Delete Recipe Error: $e");
    }
  }

  Future<void> updateRecipe(Recipe recipe) async {
    try {
      final db = await database;
      await db.update(
        'recipes',
        recipe.toMap(),
        where: 'id = ?',
        whereArgs: [recipe.id],
      );
    } catch (e) {
      throw Exception("Update Recipe Error: $e");
    }
  }
}
