import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/recipe.dart';
import '../providers/recipe_provider.dart';

class AddRecipeScreen extends StatefulWidget {
  final Recipe? recipe; // Null jika menambah, berisi data jika mengedit

  AddRecipeScreen({this.recipe});

  @override
  _AddRecipeScreenState createState() => _AddRecipeScreenState();
}

class _AddRecipeScreenState extends State<AddRecipeScreen> {
  final _formKey = GlobalKey<FormState>();
  late String _name;
  late String _preparationTime;
  late String _ingredients;
  late String _instructions;

  @override
  void initState() {
    super.initState();
    // Jika mode edit, isi form dengan data resep
    _name = widget.recipe?.name ?? '';
    _preparationTime = widget.recipe?.preparationTime ?? '';
    _ingredients = widget.recipe?.ingredients ?? '';
    _instructions = widget.recipe?.instructions ?? '';
  }

  @override
  Widget build(BuildContext context) {
    final recipeProvider = Provider.of<RecipeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.recipe == null ? 'Add Recipe' : 'Edit Recipe'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                initialValue: _name,
                decoration: InputDecoration(labelText: 'Recipe Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a recipe name';
                  }
                  return null;
                },
                onSaved: (value) {
                  _name = value!;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                initialValue: _preparationTime,
                decoration: InputDecoration(labelText: 'Preparation Time'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter preparation time';
                  }
                  return null;
                },
                onSaved: (value) {
                  _preparationTime = value!;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                initialValue: _ingredients,
                maxLines: 4,
                decoration: InputDecoration(
                  labelText: 'Ingredients',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter ingredients';
                  }
                  return null;
                },
                onSaved: (value) {
                  _ingredients = value!;
                },
              ),
              SizedBox(height: 16),
              TextFormField(
                initialValue: _instructions,
                maxLines: 4,
                decoration: InputDecoration(
                  labelText: 'Instructions',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter instructions';
                  }
                  return null;
                },
                onSaved: (value) {
                  _instructions = value!;
                },
              ),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _formKey.currentState!.save();
                    final newRecipe = Recipe(
                      id: widget.recipe?.id, // Jika edit, gunakan ID lama
                      name: _name,
                      preparationTime: _preparationTime,
                      ingredients: _ingredients,
                      instructions: _instructions,
                    );

                    if (widget.recipe == null) {
                      recipeProvider.addRecipe(newRecipe); // Tambah baru
                    } else {
                      recipeProvider.updateRecipe(newRecipe); // Update
                    }

                    Navigator.pop(context); // Kembali ke HomeScreen
                  }
                },
                child: Text(widget.recipe == null ? 'Save Recipe' : 'Update Recipe'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
