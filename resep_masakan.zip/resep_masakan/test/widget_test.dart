import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Counter increments', (WidgetTester tester) async {
    // Persiapkan aplikasi untuk pengujian
    await tester.pumpWidget(MyApp());

    // Verifikasi nilai counter yang pertama kali (0)
    expect(find.text('Counter value: 0'), findsOneWidget);
    expect(find.text('Counter value: 1'), findsNothing);

    // Tap ikon + untuk meningkatkan counter
    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    // Verifikasi nilai counter setelah peningkatan
    expect(find.text('Counter value: 0'), findsNothing);
    expect(find.text('Counter value: 1'), findsOneWidget);
  });
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: CounterScreen(),
    );
  }
}

class CounterScreen extends StatefulWidget {
  @override
  _CounterScreenState createState() => _CounterScreenState();
}

class _CounterScreenState extends State<CounterScreen> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Counter'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // Teks yang menampilkan nilai counter dengan style khusus
            Text(
              'Counter value: $_counter', // Menampilkan nilai counter
              style: TextStyle(
                fontSize: 24,               // Ukuran font 24
                fontWeight: FontWeight.bold, // Menebalkan font
                color: Colors.blue,         // Menentukan warna teks biru
              ),
            ),
            // Tombol untuk menambah counter
            IconButton(
              icon: Icon(Icons.add),
              onPressed: _incrementCounter,
            ),
          ],
        ),
      ),
    );
  }
}
